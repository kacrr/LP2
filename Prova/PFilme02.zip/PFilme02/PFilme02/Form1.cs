﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PFilme02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            Double[,] notas = new double[2, 2];
            string linha1, linha2;


            for (int pessoa = 0; pessoa < notas.GetLength(0); pessoa++)
            {
                double media = 0;
                for (int filme = 0; filme < notas.GetLength(1); filme++)
                {
                    string auxiliar = Interaction.InputBox("Pessoa" + (pessoa + 1) + ", digite a nota do " + (filme + 1) + "º filme " + ": ", "Entrada de Dados", "");

                    if (!double.TryParse(auxiliar, out notas[pessoa, filme]) || notas[pessoa, filme] < 0 || notas[pessoa, filme] > 10)
                    {
                        MessageBox.Show("Nota inválida. Digite uma nota entre 0 e 10.");
                        filme--;
                    }
                    else
                        media += notas[pessoa,filme];
                    linha1 = "Média filme " + (pessoa + 1) + ": " + media.ToString("N2") + (auxiliar);
                    linha2 = "Média filme " + (pessoa + 2) + ": " + media.ToString("N2") + (auxiliar);

                    listFilmes.Items.Add("Pessoa" + (pessoa + 1) + " Nota Filme " + (filme + 1) + ": " + (auxiliar));

                }
                media /= notas.GetLength(1);
                

            }
        }
    }
}
