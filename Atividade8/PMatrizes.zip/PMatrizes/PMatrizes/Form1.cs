﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";

            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i+1}º número", "Entrada de Dados");
                if (auxiliar =="")
                {
                    break;
                }
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("número inválido!");
                    i--;
                }
            }
            Array.Reverse(vetor);
            auxiliar = "";
            foreach(int dado in vetor)
            {
                auxiliar += dado + "\n";
            }
            //MessageBox.Show(auxiliar);

            //ou
            auxiliar = "";
            auxiliar = string.Join("\n", vetor);
            MessageBox.Show(auxiliar);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList lista = new ArrayList() { "Ana", "André", "Beatriz", "Camila", "João", "Joana", "Otávio", "Marcelo", "Pedro", "Thais" };
            lista.Remove("Otávio");
            
            string resultado = string.Join ("\n", lista.ToArray());

            //ou

            resultado = "";
            foreach (string nome in lista)
            {
                resultado += nome;
                MessageBox.Show("" + nome);
            }
            
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            /*/Double[,] notas = new double[20, 3];
            string auxiliar = "";

            for (int aluno = 0; aluno < 20; aluno++)
            {
                for(int nota = 0; nota < 3; nota++)
                {
                    auxiliar = Interaction.InputBox($"Digite o {aluno+1}º aluno");
                }
            }/*/
        }
    }
}
